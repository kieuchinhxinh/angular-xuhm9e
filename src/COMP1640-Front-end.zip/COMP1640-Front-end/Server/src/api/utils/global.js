module.exports = {
  BASEURL: 'http://localhost:8888/',
  BASEURL_FILE: 'http://localhost:8888/upload/',
  BASEURL_PROD: 'http://139.162.47.239/upload'
}
