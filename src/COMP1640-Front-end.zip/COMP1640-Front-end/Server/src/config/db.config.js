module.exports = {
  database: 'comp1640',
  uri: 'mongodb+srv://comp1640:comp1640@comp1640.qcin5pl.mongodb.net/comp1640',
  imgBucket: 'file'
}
