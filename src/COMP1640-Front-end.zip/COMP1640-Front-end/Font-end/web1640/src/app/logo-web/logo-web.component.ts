import { Component } from '@angular/core';

@Component({
  selector: 'app-logoWeb',
  templateUrl: './logo-web.component.html',
  styleUrls: ['./logo-web.component.css']
})
export class LogoWebComponent {

}
