import { Component } from '@angular/core';

@Component({
 
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent {

}
